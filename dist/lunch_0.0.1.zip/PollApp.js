"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const App_1 = require("@rocket.chat/apps-engine/definition/App");
const settings_1 = require("@rocket.chat/apps-engine/definition/settings");
const createOrderModal_1 = require("./src/lib/createOrderModal");
const createPollMessage_1 = require("./src/lib/createPollMessage");
const createPollModal_1 = require("./src/lib/createPollModal");
const finishPollMessage_1 = require("./src/lib/finishPollMessage");
const PollCommand_1 = require("./src/PollCommand");
class PollApp extends App_1.App {
    constructor(info, logger) {
        super(info, logger);
    }
    async executeViewSubmitHandler(context, read, http, persistence, modify) {
        const data = context.getInteractionData();
        const { state, } = data.view;
        if (!state) {
            return context.getInteractionResponder().viewErrorResponse({
                viewId: data.view.id,
                errors: {
                    question: 'Error creating poll',
                },
            });
        }
        try {
            await createPollMessage_1.createPollMessage(data, read, modify, persistence, data.user.id);
        }
        catch (err) {
            return context.getInteractionResponder().viewErrorResponse({
                viewId: data.view.id,
                errors: err,
            });
        }
        return {
            success: true,
        };
    }
    async executeBlockActionHandler(context, read, http, persistence, modify) {
        const data = context.getInteractionData();
        const { actionId } = data;
        switch (actionId) {
            case 'create': {
                const modal = await createPollModal_1.createPollModal({
                    data,
                    persistence,
                    modify,
                });
                return context
                    .getInteractionResponder()
                    .openModalViewResponse(modal);
            }
            case 'join': {
                const modal = await createOrderModal_1.createOrderModal({
                    data,
                    persistence,
                    modify,
                });
                return context
                    .getInteractionResponder()
                    .openModalViewResponse(modal);
            }
            case 'finish': {
                try {
                    await finishPollMessage_1.finishPollMessage({
                        data,
                        read,
                        persistence,
                        modify,
                    });
                }
                catch (e) {
                    const { room } = context.getInteractionData();
                    const errorMessage = modify
                        .getCreator()
                        .startMessage()
                        .setSender(context.getInteractionData().user)
                        .setText(e.message)
                        .setUsernameAlias('Lunch');
                    if (room) {
                        errorMessage.setRoom(room);
                    }
                    modify
                        .getNotifier()
                        .notifyUser(context.getInteractionData().user, errorMessage.getMessage());
                }
            }
        }
        return {
            success: true,
            triggerId: data.triggerId,
        };
    }
    async initialize(configuration) {
        await configuration.slashCommands.provideSlashCommand(new PollCommand_1.PollCommand());
        await configuration.settings.provideSetting({
            id: 'use-user-name',
            i18nLabel: 'Use name attribute to display voters, instead of username',
            i18nDescription: 'When checked, display voters as full user names instead of username',
            required: false,
            type: settings_1.SettingType.BOOLEAN,
            public: true,
            packageValue: false,
        });
    }
}
exports.PollApp = PollApp;
