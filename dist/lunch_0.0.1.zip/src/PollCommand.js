"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const createPollModal_1 = require("./lib/createPollModal");
class PollCommand {
    constructor() {
        this.command = 'lunch';
        this.i18nParamsExample = 'params_example';
        this.i18nDescription = 'cmd_description';
        this.providesPreview = false;
    }
    async executor(context, read, modify, http, persis) {
        const triggerId = context.getTriggerId();
        const data = {
            room: context.getRoom().value,
            threadId: context.getThreadId(),
        };
        const question = context.getArguments().join(' ');
        if (triggerId) {
            const modal = await createPollModal_1.createPollModal({
                question,
                persistence: persis,
                modify,
                data,
            });
            await modify
                .getUiController()
                .openModalView(modal, { triggerId }, context.getSender());
        }
    }
}
exports.PollCommand = PollCommand;
